﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace image_app
{
	public partial class Form1 : Form

	{
		
		ArrayList FilesNames = new ArrayList();
		private int ImageListCount;
		private int imageindex = 0;
		PictureBox pic = new PictureBox();


	
		public Form1()
		{
			InitializeComponent();
			
			SizeChanged+= ImageShowPanel_Rsize; 
			AddPhotoBtn.Click += Default_properties;
			AddPhotoBtn.Click += PhotoBtns_Click;
			SelectPhotoBtn.Click += Default_properties;
			SelectPhotoBtn.Click += PhotoBtns_Click;
		}

		private PictureBox Make_PictureBox()
		{

			PictureBox pic = new PictureBox
			{
				SizeMode = PictureBoxSizeMode.StretchImage,
				Size = ImageShowPanel.Size,

		    };
		
			return pic;
		}
		private FlowLayoutPanel Make_FlowLayoutPanel()
		{
			FlowLayoutPanel fl = new FlowLayoutPanel
			{
				FlowDirection = FlowDirection.LeftToRight,
				Size = ImageShowPanel.Size,
				AutoScroll = true,
				Dock = DockStyle.Fill
			};
			ImageShowPanel.Controls.Add(fl);
			return fl;
		}
		private DialogResult Return_MessageBoxResult(string s)
		{
			DialogResult MB = MessageBox.Show(s, "Warning", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
			return MB;
		}
		private void Add()
		{
			foreach (string s in ofd.FileNames)
			{
				
					ImageLB.Items.Add(Path.GetFileName(s));
					FilesNames.Add(s);

				
			}
		}

		private void PhotoBtns_Click(object sender, EventArgs e)
		{
			Button Btn = (Button)sender; ;
			ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);

			if (ofd.ShowDialog() == DialogResult.OK)
			{

				if (Btn.Name == "SelectPhotoBtn")
				{
					DialogResult r = MessageBox.Show(" This will delete all photos and add from first complete anyway", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
					if (r == DialogResult.Yes)
					{
						ImageLB.Items.Clear();
						FilesNames.Clear();
						Add();
					}
					
				}
				else
				{
					Add();
				}


				PATHtxt.Text = Path.GetDirectoryName(ofd.FileName);
			}
			else
			{
				if (Btn.Name == "SelectPhotoBtn")
				{
		
					if (Return_MessageBoxResult("you not select new photos") == DialogResult.Retry)
					{
						PhotoBtns_Click(sender, e);
					}
				}
				else
				{

					
					if (Return_MessageBoxResult("you not add any photos") == DialogResult.Retry)
					{
						PhotoBtns_Click(sender, e);
					}

				}

			}

		}

		private void Default_properties(object sender, EventArgs e)
		{
			timer1.Stop();
			ImageName.Visible = false;
			ImageShowPanel.Controls.Clear();
			imageindex = 0;
			BtnPanel.Visible = false;
			
			ImageShowPanel.Dock = DockStyle.Fill;

		}

		private void MultipictureToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Default_properties(sender, e);
			FlowLayoutPanel FP = Make_FlowLayoutPanel();
			foreach (int ItemIndex in ImageLB.SelectedIndices)
			{
				PictureBox pic = Make_PictureBox();
				pic.Size = new Size(150, 150);
				pic.Image = Image.FromFile(FilesNames[ItemIndex].ToString());
				FP.Controls.Add(pic);

			}
		}

		private void SinglePictureToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Default_properties(sender, e);
			PictureBox pic = Make_PictureBox();
			pic.Dock = DockStyle.Fill;
			if (ImageLB.SelectedIndices.Count == 1)
			{
				pic.Image = Image.FromFile(FilesNames[ImageLB.SelectedIndex].ToString());
				ImageShowPanel.Controls.Add(pic);
			}
			else
			{
				Return_MessageBoxResult("Select one photo");
			}
		}
		 
		private void ImageShowPanel_Rsize(object sender, EventArgs e)

		{
			var ImageGB_WidthPadding = ImageViewerGB.Padding.Left + ImageViewerGB.Padding.Right;
			var ImageGB_HightPadding = ImageViewerGB.Padding.Bottom + ImageViewerGB.Padding.Top;
			ImageShowPanel.Width = ImageViewerGB.Width-(ImageGB_WidthPadding);
				ImageShowPanel.Height = ImageViewerGB.Height - (ImageName.Height + BtnPanel.Height+ ImageGB_HightPadding);
			
		}
		private void SlideShowToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (ImageLB.Items.Count != 0) {
				Default_properties(sender, e);
				ImageName.Visible = true;
				BtnPanel.Visible = true;
				ImageShowPanel.Dock = DockStyle.None;
				ImageShowPanel_Rsize(sender, e);
				pic = Make_PictureBox();
				ImageShowPanel.Controls.Add(pic);
				pic.Dock = DockStyle.Fill;
				ImageListCount = ImageLB.Items.Count;
				timer1.Start();
			}
			else
			{
				DialogResult s = Return_MessageBoxResult("there is no photo to show");
			}
			
		}
		private void PictureBorder_MouseHover(object sender, EventArgs e)
		{
			PictureBox s = (PictureBox)sender;
			s.BorderStyle = BorderStyle.Fixed3D;
		}
		private void PictureBorder_MouseOut(object sender, EventArgs e)
		{
			PictureBox s = (PictureBox)sender;
			s.BorderStyle = BorderStyle.None;
		}

		private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Close();

		}

		private void Timer1_Tick(object sender, EventArgs e)
		{
			if (imageindex != ImageListCount)
			{
				pic.Image = Image.FromFile(FilesNames[imageindex].ToString());
				ImageName.Text = Path.GetFileName(FilesNames[imageindex].ToString());
				imageindex++;
			}
			else
			{
				imageindex = 0;

			}
		}

		bool timer_Work = true;
		private void StartBtn_Click(object sender, EventArgs e)
		{
			if (!timer_Work)
			{
				timer_Work = true;
				SlideShowToolStripMenuItem_Click(sender, e);

			}
		
		}

		private void StopBtn_Click(object sender, EventArgs e)
		{
			timer_Work = false;
			timer1.Stop();
		}

		
		
	}
}
