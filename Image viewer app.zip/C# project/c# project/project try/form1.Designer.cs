﻿namespace image_app
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.ImageLB = new System.Windows.Forms.ListBox();
			this.ModesCMS = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.singlePictureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.multipictureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.slideShowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.ImageShowPanel = new System.Windows.Forms.Panel();
			this.ImageName = new System.Windows.Forms.StatusBar();
			this.BtnPanel = new System.Windows.Forms.Panel();
			this.StopBtn = new System.Windows.Forms.Button();
			this.StartBtn = new System.Windows.Forms.Button();
			this.ImageViewerGB = new System.Windows.Forms.GroupBox();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.ofd = new System.Windows.Forms.OpenFileDialog();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.SelectPhotoBtn = new System.Windows.Forms.Button();
			this.AddPhotoBtn = new System.Windows.Forms.Button();
			this.ImagedirectoryGB = new System.Windows.Forms.GroupBox();
			this.PATHtxt = new System.Windows.Forms.TextBox();
			this.groupBox1.SuspendLayout();
			this.ModesCMS.SuspendLayout();
			this.BtnPanel.SuspendLayout();
			this.ImageViewerGB.SuspendLayout();
			this.ImagedirectoryGB.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
			this.groupBox1.BackColor = System.Drawing.Color.Transparent;
			this.groupBox1.Controls.Add(this.ImageLB);
			this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox1.Location = new System.Drawing.Point(16, 16);
			this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new System.Windows.Forms.Padding(6);
			this.groupBox1.Size = new System.Drawing.Size(320, 566);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Images List";
			// 
			// ImageLB
			// 
			this.ImageLB.BackColor = System.Drawing.Color.WhiteSmoke;
			this.ImageLB.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.ImageLB.ContextMenuStrip = this.ModesCMS;
			this.ImageLB.DisplayMember = "1";
			this.ImageLB.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ImageLB.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ImageLB.ForeColor = System.Drawing.Color.Black;
			this.ImageLB.FormattingEnabled = true;
			this.ImageLB.HorizontalScrollbar = true;
			this.ImageLB.ItemHeight = 15;
			this.ImageLB.Location = new System.Drawing.Point(6, 24);
			this.ImageLB.Name = "ImageLB";
			this.ImageLB.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.ImageLB.Size = new System.Drawing.Size(308, 536);
			this.ImageLB.TabIndex = 0;
			this.toolTip1.SetToolTip(this.ImageLB, "Click rIght click and chosse  mode");
			// 
			// ModesCMS
			// 
			this.ModesCMS.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.singlePictureToolStripMenuItem,
            this.multipictureToolStripMenuItem,
            this.slideShowToolStripMenuItem,
            this.exitToolStripMenuItem});
			this.ModesCMS.Name = "contextMenuStrip1";
			this.ModesCMS.Size = new System.Drawing.Size(147, 92);
			// 
			// singlePictureToolStripMenuItem
			// 
			this.singlePictureToolStripMenuItem.Name = "singlePictureToolStripMenuItem";
			this.singlePictureToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
			this.singlePictureToolStripMenuItem.Text = "Single picture";
			this.singlePictureToolStripMenuItem.Click += new System.EventHandler(this.SinglePictureToolStripMenuItem_Click);
			// 
			// multipictureToolStripMenuItem
			// 
			this.multipictureToolStripMenuItem.Name = "multipictureToolStripMenuItem";
			this.multipictureToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
			this.multipictureToolStripMenuItem.Text = "Multi-picture";
			this.multipictureToolStripMenuItem.Click += new System.EventHandler(this.MultipictureToolStripMenuItem_Click);
			// 
			// slideShowToolStripMenuItem
			// 
			this.slideShowToolStripMenuItem.Name = "slideShowToolStripMenuItem";
			this.slideShowToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
			this.slideShowToolStripMenuItem.Text = "Slide show";
			this.slideShowToolStripMenuItem.Click += new System.EventHandler(this.SlideShowToolStripMenuItem_Click);
			// 
			// exitToolStripMenuItem
			// 
			this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
			this.exitToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
			this.exitToolStripMenuItem.Text = "Exit";
			this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click);
			// 
			// ImageShowPanel
			// 
			this.ImageShowPanel.BackColor = System.Drawing.Color.WhiteSmoke;
			this.ImageShowPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ImageShowPanel.Location = new System.Drawing.Point(6, 24);
			this.ImageShowPanel.Margin = new System.Windows.Forms.Padding(0);
			this.ImageShowPanel.Name = "ImageShowPanel";
			this.ImageShowPanel.Size = new System.Drawing.Size(671, 367);
			this.ImageShowPanel.TabIndex = 2;
			// 
			// ImageName
			// 
			this.ImageName.Location = new System.Drawing.Point(6, 353);
			this.ImageName.Margin = new System.Windows.Forms.Padding(0);
			this.ImageName.Name = "ImageName";
			this.ImageName.Size = new System.Drawing.Size(671, 38);
			this.ImageName.TabIndex = 3;
			this.ImageName.Visible = false;
			// 
			// BtnPanel
			// 
			this.BtnPanel.BackColor = System.Drawing.Color.WhiteSmoke;
			this.BtnPanel.Controls.Add(this.StopBtn);
			this.BtnPanel.Controls.Add(this.StartBtn);
			this.BtnPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.BtnPanel.Location = new System.Drawing.Point(6, 391);
			this.BtnPanel.Margin = new System.Windows.Forms.Padding(0);
			this.BtnPanel.Name = "BtnPanel";
			this.BtnPanel.Size = new System.Drawing.Size(671, 35);
			this.BtnPanel.TabIndex = 0;
			this.BtnPanel.Visible = false;
			// 
			// StopBtn
			// 
			this.StopBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.StopBtn.BackColor = System.Drawing.Color.Red;
			this.StopBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.StopBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.StopBtn.ForeColor = System.Drawing.Color.White;
			this.StopBtn.Location = new System.Drawing.Point(383, 3);
			this.StopBtn.Margin = new System.Windows.Forms.Padding(0);
			this.StopBtn.Name = "StopBtn";
			this.StopBtn.Size = new System.Drawing.Size(82, 32);
			this.StopBtn.TabIndex = 1;
			this.StopBtn.Text = "Stop ";
			this.toolTip1.SetToolTip(this.StopBtn, "Stop SlideShow");
			this.StopBtn.UseVisualStyleBackColor = false;
			this.StopBtn.Click += new System.EventHandler(this.StopBtn_Click);
			// 
			// StartBtn
			// 
			this.StartBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.StartBtn.BackColor = System.Drawing.Color.Green;
			this.StartBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.StartBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.StartBtn.ForeColor = System.Drawing.Color.White;
			this.StartBtn.Location = new System.Drawing.Point(288, 3);
			this.StartBtn.Margin = new System.Windows.Forms.Padding(0);
			this.StartBtn.Name = "StartBtn";
			this.StartBtn.Size = new System.Drawing.Size(81, 31);
			this.StartBtn.TabIndex = 0;
			this.StartBtn.Text = "Start ";
			this.toolTip1.SetToolTip(this.StartBtn, "Start SlideShow");
			this.StartBtn.UseVisualStyleBackColor = false;
			this.StartBtn.Click += new System.EventHandler(this.StartBtn_Click);
			// 
			// ImageViewerGB
			// 
			this.ImageViewerGB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.ImageViewerGB.BackColor = System.Drawing.Color.Transparent;
			this.ImageViewerGB.Controls.Add(this.ImageName);
			this.ImageViewerGB.Controls.Add(this.ImageShowPanel);
			this.ImageViewerGB.Controls.Add(this.BtnPanel);
			this.ImageViewerGB.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ImageViewerGB.Location = new System.Drawing.Point(367, 146);
			this.ImageViewerGB.Margin = new System.Windows.Forms.Padding(0);
			this.ImageViewerGB.Name = "ImageViewerGB";
			this.ImageViewerGB.Padding = new System.Windows.Forms.Padding(6);
			this.ImageViewerGB.Size = new System.Drawing.Size(683, 432);
			this.ImageViewerGB.TabIndex = 0;
			this.ImageViewerGB.TabStop = false;
			this.ImageViewerGB.Text = "Image Viewer";
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
			// 
			// ofd
			// 
			this.ofd.FileName = "openFileDialog1";
			this.ofd.Filter = "Images|*.PNG;*.JPG|JPG|*.jpg|PNG|*.png";
			this.ofd.Multiselect = true;
			this.ofd.Title = "Select Photos";
			// 
			// SelectPhotoBtn
			// 
			this.SelectPhotoBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.SelectPhotoBtn.BackColor = System.Drawing.Color.DarkCyan;
			this.SelectPhotoBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.SelectPhotoBtn.ForeColor = System.Drawing.Color.White;
			this.SelectPhotoBtn.Location = new System.Drawing.Point(550, 29);
			this.SelectPhotoBtn.Margin = new System.Windows.Forms.Padding(7);
			this.SelectPhotoBtn.Name = "SelectPhotoBtn";
			this.SelectPhotoBtn.Size = new System.Drawing.Size(110, 43);
			this.SelectPhotoBtn.TabIndex = 4;
			this.SelectPhotoBtn.Text = "Select  New Photos";
			this.toolTip1.SetToolTip(this.SelectPhotoBtn, "Delete recent photo and choose from first");
			this.SelectPhotoBtn.UseVisualStyleBackColor = false;
			// 
			// AddPhotoBtn
			// 
			this.AddPhotoBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.AddPhotoBtn.BackColor = System.Drawing.Color.DarkCyan;
			this.AddPhotoBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.AddPhotoBtn.ForeColor = System.Drawing.Color.White;
			this.AddPhotoBtn.Location = new System.Drawing.Point(417, 29);
			this.AddPhotoBtn.Margin = new System.Windows.Forms.Padding(7);
			this.AddPhotoBtn.Name = "AddPhotoBtn";
			this.AddPhotoBtn.Size = new System.Drawing.Size(108, 43);
			this.AddPhotoBtn.TabIndex = 3;
			this.AddPhotoBtn.Text = "Add Photos";
			this.toolTip1.SetToolTip(this.AddPhotoBtn, "Add More Photo");
			this.AddPhotoBtn.UseVisualStyleBackColor = false;
			// 
			// ImagedirectoryGB
			// 
			this.ImagedirectoryGB.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.ImagedirectoryGB.Controls.Add(this.PATHtxt);
			this.ImagedirectoryGB.Controls.Add(this.SelectPhotoBtn);
			this.ImagedirectoryGB.Controls.Add(this.AddPhotoBtn);
			this.ImagedirectoryGB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.ImagedirectoryGB.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
			this.ImagedirectoryGB.Location = new System.Drawing.Point(367, 26);
			this.ImagedirectoryGB.Name = "ImagedirectoryGB";
			this.ImagedirectoryGB.Size = new System.Drawing.Size(683, 100);
			this.ImagedirectoryGB.TabIndex = 3;
			this.ImagedirectoryGB.TabStop = false;
			this.ImagedirectoryGB.Text = "Image Directory";
			// 
			// PATHtxt
			// 
			this.PATHtxt.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.PATHtxt.BackColor = System.Drawing.Color.WhiteSmoke;
			this.PATHtxt.Enabled = false;
			this.PATHtxt.Location = new System.Drawing.Point(24, 39);
			this.PATHtxt.Margin = new System.Windows.Forms.Padding(4);
			this.PATHtxt.Name = "PATHtxt";
			this.PATHtxt.Size = new System.Drawing.Size(371, 25);
			this.PATHtxt.TabIndex = 5;
			this.PATHtxt.Text = "Photos Path";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(1067, 588);
			this.ContextMenuStrip = this.ModesCMS;
			this.Controls.Add(this.ImagedirectoryGB);
			this.Controls.Add(this.ImageViewerGB);
			this.Controls.Add(this.groupBox1);
			this.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ForeColor = System.Drawing.Color.White;
			this.Margin = new System.Windows.Forms.Padding(4);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Picture ";
			this.groupBox1.ResumeLayout(false);
			this.ModesCMS.ResumeLayout(false);
			this.BtnPanel.ResumeLayout(false);
			this.ImageViewerGB.ResumeLayout(false);
			this.ImagedirectoryGB.ResumeLayout(false);
			this.ImagedirectoryGB.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ListBox ImageLB;
		private System.Windows.Forms.Panel ImageShowPanel;
		private System.Windows.Forms.GroupBox ImageViewerGB;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.OpenFileDialog ofd;
		private System.Windows.Forms.ContextMenuStrip ModesCMS;
		private System.Windows.Forms.ToolStripMenuItem singlePictureToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem multipictureToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem slideShowToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
		private System.Windows.Forms.StatusBar ImageName;
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.Panel BtnPanel;
		private System.Windows.Forms.Button StopBtn;
		private System.Windows.Forms.Button StartBtn;
		private System.Windows.Forms.GroupBox ImagedirectoryGB;
		private System.Windows.Forms.TextBox PATHtxt;
		private System.Windows.Forms.Button SelectPhotoBtn;
		private System.Windows.Forms.Button AddPhotoBtn;
	}
}